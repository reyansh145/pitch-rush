# Pitch Rush: self-hosted online mode

Two files make it work:
- `server.js`: the game server (usernames, friend requests, invites, live 1v1 relay)
- `index.html`: the game, already wired to talk to that server

## Quick start (on your own computer)
1. Install Node.js 18+.
2. In this folder run `npm install`, then `npm start` (the server listens on port 8080).
3. Open `index.html` in two browser windows. Use two different browser profiles, or one normal and one private window, so each gets its own account. Click Play Online.

## Putting it on the internet
1. Run `server.js` on a host that keeps Node running (Render, Railway, Fly.io, a VPS...).
2. Host `index.html` anywhere (GitHub Pages, Netlify, itch.io...).
3. In `index.html` change `window.PITCH_SERVER_URL` to your server address.
   If the page is served over https, the address must start with `wss://`
   (hosts like Render and Railway give you https/wss automatically).
4. Optional: lock the server to your site with the env var `ALLOWED_ORIGINS=https://yourgame.example`.

## Notes
- Accounts: each browser gets a random ID and secret saved in localStorage, plus a username.
  Clearing site data means a new account. There are no passwords or emails.
- Data is stored in `data.json` next to the server (set `DATA_FILE` to change it).
  Many free hosts wipe their disk on restart, so use a persistent disk to keep accounts.
- The server checks who may change what: you can only edit your own profile, only the receiver can accept a request, and so on.
- Matches: the first player runs the game and the second sends controls. There is no lag compensation.
